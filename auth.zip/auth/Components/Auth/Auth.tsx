"use client"


import React, { useState } from 'react'

import styles from './Auth.module.css'

import { signIn } from 'next-auth/react'


import { useRouter } from 'next/navigation'


// For Components
import Wrapper from '@/Components/Wrapper/Wrapper'
import { InputBox } from '@/Components/InputBox/InputBox'

export const Auth = () => {

  const [Name, setName] = useState('')
  const [Email, setEmail] = useState('')
  const [Password, setPassword] = useState('')
  const [varient, SetVarient] = useState("Login")
  const [SuccessMessage, SetSuccessMessage] = useState("")
  const [ErrorMessage, SetErrorMessage] = useState("")

  const router = useRouter()

  const SwitchVarient = () => {
    SetVarient(varient === "Login" ? "Register" : "Login")

  }

  // To Register

  const HandleRegisterSubmit = async (e: any) => {
    e.preventDefault()

    try {

      // For Checking Email Already Used Or Not
      const UserExists_Res = await fetch("/api/UserExists", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ Email })
      })

      const { user } = await UserExists_Res.json()
      if (user) {
        SetSuccessMessage("")
        SetErrorMessage("")
        SetErrorMessage("Email Id Already Used!")
        return;
      }




      const res = await fetch("/api/Register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          Name, Email, Password
        })
      })

      if (res.ok) {
        setName("")
        setEmail("")
        setPassword("")
        SetSuccessMessage("")
        SetErrorMessage("")
        // console.log("Registered Successfully")
        SetSuccessMessage("Registered Successfully Login Now!")
        SwitchVarient()


      } else {
        // console.log("Error")
        SetSuccessMessage("")
        SetErrorMessage("")
        SetErrorMessage("Something Went Wrong")
      }


    } catch (error) {
      SetSuccessMessage("")
      SetErrorMessage("")
      SetErrorMessage("Opps! Error on Our Side")
      // console.log(error)
    }

  }




  // To  Login
  const HandleLoginSubmit = async (e: any) => {
    e.preventDefault()

    try {

      const res = await signIn("credentials", {
        Email,
        Password,
        redirect: false
      })

      if (res && res.error) {
        // console.log("Wrong Credentials")
        SetSuccessMessage("")
        SetErrorMessage("Wrong Credentials")
        return
      }
      // if Credentials Match
      // console.log("All Set")
      SetErrorMessage("")
      SetSuccessMessage("Logging In....")
      router.replace("/Dashboard")

    } catch (error) {
      // console.log(error)
      SetErrorMessage("Opps! Error on Our Side")
    }
  }


  return (
    <Wrapper>
      <div className={styles.Auth}>
        <form onSubmit={varient === 'Login' ? HandleLoginSubmit : HandleRegisterSubmit}>
          <h6>
            {varient === 'Login' ? 'Login  Now' : 'Register Now'}
          </h6>


          {
            varient === 'Register' && (
              <InputBox
                labelText='Your Name'
                value={Name}
                onChange={(e: any) => setName(e.target.value)}
                Type='text'
                Id='YourName'
              />
            )
          }

          <InputBox
            labelText='Your Email'
            value={Email}
            onChange={(e: any) => setEmail(e.target.value)}
            Type='email'
            Id='email'
          />

          <InputBox
            labelText='Your Password'
            value={Password}
            onChange={(e: any) => setPassword(e.target.value)}
            Type='password'
            Id='email'
          />

          <button className={styles.Btn}>
            {
              varient === "Login" ? "Login Now" : "Register Now"
            }
          </button>

          <p className={styles.CustomMess}>
            {
              varient === 'Login' ? "Don't have an Account? " : "Already Have An Acccount?"
            }
            <span onClick={SwitchVarient}>
              {varient === 'Login' ? " Register Now" : " Login Now"}
            </span>
          </p>

          {/* For SuccessMessage */}
          {
            SuccessMessage && (
              <p className={styles.SuccessMessage}>
                {SuccessMessage}
              </p>
            )
          }


          {/* For Error Message */}
          {
            ErrorMessage && (
              <p className={styles.ErrorMessage}>
                {ErrorMessage}
              </p>
            )
          }







        </form>
      </div>
    </Wrapper>
  )
}
