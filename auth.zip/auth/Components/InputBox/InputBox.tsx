import React from 'react'


import styles from './InputBox.module.css'

interface InputBoxProps {
    labelText: string,
    Id: string,
    Type: string,
    value: string,
    onChange?: any
}


export const InputBox = (
    {
        labelText, Id, Type, value, onChange
    }: InputBoxProps
) => {
    return (
        <div className={styles.InputBox}>
            <label htmlFor={Id}>{labelText}</label><br />
            <input type={Type} value={value} required onChange={onChange} id={Id} />
        </div>
    )
}
