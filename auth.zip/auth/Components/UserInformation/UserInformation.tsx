"use client"
import React from 'react'

import styles from './UserInformation.module.css'


import { useSession, signOut } from 'next-auth/react'

export const UserInformation = () => {
    const { data: session, status } = useSession()

    if (status === 'loading') {
        return (
            <>
                <p>Loading...</p>
            </>
        )
    }

    if (status === 'authenticated') {



        return (
            <>
                <div className={styles.UserInformation}>
                    <div className={styles.UserInfoMain}>
                        <h6><span>Name</span> : {session?.user?.name}</h6>
                        <h6><span>Email</span> : {session?.user?.email}</h6>
                        <button onClick={() => signOut()}>Logout</button>
                    </div>
                </div>
            </>
        )
    }

    return (
        <p>Redirecting ......</p>
    )

}
