import ConnectToDb from "@/Lib/ConnectToDb";
import User from "@/Models/User";
import NextAuth from "next-auth/next";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from 'bcryptjs'
import { NextAuthOptions } from "next-auth";


interface AuthProps {
    Email: string,
    Password: string,
}

export const authOptions: NextAuthOptions = {
    providers: [
        CredentialsProvider({
            name: "credentials",
            credentials: {},

            async authorize(credentials) {
                const { Email, Password } = credentials as AuthProps;

                try {
                    await ConnectToDb();
                    const user = await User.findOne({ Email });
                    // console.log(user);
                    if (!user) {
                        return null;
                    }

                    const isValidPassword = await bcrypt.compare(Password, user.Password);
                    if (!isValidPassword) {
                        return null;
                    }

                    return {
                        id: user._id,
                        name: user.Name,
                        email: user.Email
                    }

                } catch (error) {
                    console.error("Authorization error:", error);
                    return null;
                }

            }

        })
    ],
    session: {
        strategy: "jwt",
    },
    secret: process.env.NEXTAUTH_SECRET,
    pages: {
        // Sign In Route
        signIn: '/'
    }
}


const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }
