// For Connection
import ConnectToDb from "@/Lib/ConnectToDb";

// For Schema
import User from "@/Models/User";


import { NextResponse } from "next/server";
import bcrypt from 'bcryptjs'





export async function POST(req: Request) {
    try {

        const {
            Name, Email, Password
        } = await req.json()

        const hashedPassword = await bcrypt.hash(Password, 10);

        await ConnectToDb()
        await User.create({
            Name, Email, Password: hashedPassword
        })

        return NextResponse.json({
            message: "Registered Successfully"
        }, { status: 201 })

    } catch (error) {
        console.log(error)
    }
}