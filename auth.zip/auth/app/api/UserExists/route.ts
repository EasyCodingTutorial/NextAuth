import ConnectToDb from "@/Lib/ConnectToDb";
import User from "@/Models/User";

import { NextResponse } from "next/server";


export async function POST(req: Request) {
    try {
        await ConnectToDb()
        const { Email } = await req.json()
        const user = await User.findOne({ Email })
        console.log(user)
        return NextResponse.json({ user })
    } catch (error) {
        console.log(error)
    }
}



