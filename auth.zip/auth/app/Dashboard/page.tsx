import React from 'react'
import { UserInformation } from '@/Components/UserInformation/UserInformation'

const DashBoardPage = () => {
    return (
        <>
            <UserInformation />
        </>
    )
}

export default DashBoardPage