import styles from "./page.module.css";

// For Components
import { Auth } from "@/Components/Auth/Auth";

export default function Home() {
  return (
    <>
      <Auth />
    </>
  );
}
